#ifndef GOOGLETESTING_H_INCLUDED
#define GOOGLETESTING_H_INCLUDED




#endif // GOOGLETESTING_H_INCLUDED


/*
void initializeCalendar(Calendar &calendar, int startYear, int endYear){
	calendar.setYears(startYear, endYear);
	calendar.initializeYearList();

}
*/
